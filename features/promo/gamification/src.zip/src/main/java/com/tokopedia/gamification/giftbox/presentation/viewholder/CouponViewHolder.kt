package com.tokopedia.gamification.giftbox.presentation.viewholder

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.tokopedia.gamification.R


class CouponViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
    companion object{
         val LAYOUT = com.tokopedia.gamification.R.layout.list_item_reward_coupon
    }

    fun bind(){}
}