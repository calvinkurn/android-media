package com.tokopedia.gamification.giftbox.presentation.activities

import com.tokopedia.gamification.giftbox.presentation.fragments.GiftBoxDailyFragment

class GiftBoxDailyActivity : BaseGiftBoxActivity() {
    override fun getDestinationFragment() = GiftBoxDailyFragment()
}