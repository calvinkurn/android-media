package com.tokopedia.gamification.giftbox.presentation.activities

import com.tokopedia.gamification.giftbox.presentation.fragments.GiftBoxTapTapFragment

class GiftBoxTapTapActivity : BaseGiftBoxActivity() {

    override fun getDestinationFragment() = GiftBoxTapTapFragment()

}