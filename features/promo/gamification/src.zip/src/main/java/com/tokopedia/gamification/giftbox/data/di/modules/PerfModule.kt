package com.tokopedia.gamification.giftbox.data.di.modules

import com.tokopedia.gamification.giftbox.data.di.scope.GiftBoxScope

@GiftBoxScope
class PerfModule {

}