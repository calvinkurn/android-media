package com.tokopedia.gamification.giftbox.presentation.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatImageView
import com.tokopedia.gamification.R
import com.tokopedia.gamification.giftbox.presentation.helpers.dpToPx

class GamificationRoundImageView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {
    var radius = 0f
    val path = Path()
    val rectF = RectF()

    init {
        attrs?.let { attributes ->
            val typedArray =
                    context.theme.obtainStyledAttributes(attributes, com.tokopedia.gamification.R.styleable.GamificationRoundImageView, 0, 0)
            radius = typedArray.getDimension(com.tokopedia.gamification.R.styleable.GamificationRoundImageView_gfRoundImageRadius, dpToPx(8))
        }
    }

    override fun onDraw(canvas: Canvas?) {
        if (rectF.right > 0) {
            path.addRoundRect(rectF, radius, radius, Path.Direction.CW)
            canvas?.clipPath(path)
        }
        super.onDraw(canvas)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rectF.top = 0f
        rectF.left = 0f
        rectF.right = w.toFloat()
        rectF.bottom = h.toFloat()
    }
}