package com.tokopedia.gamification;

import com.tokopedia.url.TokopediaUrl;

/**
 * Created by nabillasabbaha on 3/28/18.
 */

public class GamificationUrl {

    public static String GQL_BASE_URL = TokopediaUrl.Companion.getInstance().getGQL();
}
