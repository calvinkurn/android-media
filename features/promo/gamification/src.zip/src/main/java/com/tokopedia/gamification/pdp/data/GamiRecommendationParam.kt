package com.tokopedia.gamification.pdp.data

class GamiRecommendationParam {

}