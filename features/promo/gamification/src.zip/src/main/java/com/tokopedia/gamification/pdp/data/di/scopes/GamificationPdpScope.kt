package com.tokopedia.gamification.pdp.data.di.scopes


import javax.inject.Scope

@MustBeDocumented
@Scope
@Retention
annotation class GamificationPdpScope