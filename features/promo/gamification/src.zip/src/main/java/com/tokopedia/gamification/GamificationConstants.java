package com.tokopedia.gamification;

public interface GamificationConstants {

    interface GraphQlVariableKeys {
        String TOKEN_ID = "tokenUserID";
        String TOKEN_ID_STR = "tokenUserIDstr";
        String CAMPAIGN_ID = "campaignID";
    }

    interface EggImageUrlIndex {
        int INDEX_TOKEN_EMPTY = 0;
        int INDEX_TOKEN_FULL = 0;
        int INDEX_TOKEN_CRACKED = 9;
        int INDEX_TOKEN_LEFT = 10;
        int INDEX_TOKEN_RIGHT = 11;
        int IMAGE_ARRAY_SIZE_NORMAL = 12;
        int IMAGE_ARRAY_SIZE_EMPTY = 1;
    }

    interface GiftBoxPerf {
        String GIFT_BOX_PLT_PREPARE_METRICS = "gift_box_plt_prepare_metrics";
        String GIFT_BOX_PLT_NETWORK_METRICS = "gift_box_plt_network_metrics";
        String GIFT_BOX_PLT_RENDER_METRICS = "gift_box_plt_render_metrics";
    }

}
