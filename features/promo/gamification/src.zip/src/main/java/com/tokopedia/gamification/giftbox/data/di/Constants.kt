package com.tokopedia.gamification.giftbox.data.di

const val GIFT_BOX_DAILY = "GIFT_BOX_DAILY"
const val GIFT_BOX_DAILY_REWARD = "GIFT_BOX_DAILY_REWARD"
const val GET_COUPON_DETAIL = "GET_COUPON_DETAIL"
const val AUTO_APPLY = "AUTO_APPLY"
const val GAMI_REMIND_ME = "GAMI_REMIND_ME"
const val GAMI_REMIND_ME_CHECK = "GAMI_REMIND_ME_CHECK"

const val GAMI_TAP_EGG_HOME = "GAMI_TAP_EGG_HOME"
const val GAMI_TAP_CRACK_EGG = "GAMI_TAP_CRACK_EGG"
const val IO = "IO"
const val MAIN = "MAIN"
