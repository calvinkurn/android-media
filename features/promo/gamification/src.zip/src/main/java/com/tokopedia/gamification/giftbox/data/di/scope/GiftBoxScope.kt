package com.tokopedia.gamification.giftbox.data.di.scope

import javax.inject.Scope

@Scope
@Retention
annotation class GiftBoxScope